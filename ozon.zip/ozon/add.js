var messages = Array(
    [
      [
        "Шахназа",
        "img/ppl/seva.jpg",
        'Салом рахмат катта мен 3 кун олдин айфон ютгандим бугун олиб келишди <a href="img1/tel/zor.jpg" data-lightbox="roadtrip"><img src="img1/tel/zor.jpg" alt=""></a>',
      ],
      [
        
        "Севара",
        "img/ppl/shaxnoz.jpg",
        "@Шахноза: Ооо табриклайман опа мен кир мошина ютдим менга телефон килишди даставка килиш учун адрес сорашди",
      ],
      ["Мафтуна", "img/ppl/maftuna.jpg", '@Севара: мана менгахам телевизор чикди мен 960 рубл даставка пулни толадим кеча обкеберишди <a href="img1/tel/televizor.jpg" data-lightbox="roadtrip"><img src="img1/tel/televizor.jpg" alt=""></a>'],
      // ["Бобур", "img/ppl/мансур.jpg", "@Мафтуна: достафка пулини кайердан канака килиб толадиз?"],
      // ["Мафтуна", "img/ppl/maftuna.jpg", 'картамдан толадим пластик карта болиши керак доставка пулини толашиз учун',],
      ["Мансур Алимов", "img/ppl/jamshid.jpg", 'Uzum marketga raxmat 3 kun oldin ayfon yutgandim ishonmay turgandim xozirgina pochtadan oldim pochta orqali jonatishipdi<a href="img1/tel/jentranomer.jpg" data-lightbox="roadtrip"><img src="img1/tel/jentranomer.jpg" alt=""></a>'],
      [
        "Мафтуна",
        "img/ppl/maftuna.jpg",
        "хамма давлатга доставка бормикан?",
      ],
      ["Шахназа", "img/ppl/seva.jpg", "ха бор екан"],
      ["Мафтуна", "img/ppl/maftuna.jpg", "ха унда бемалол доставка пулини толасам боларкан рахмат Узум маркетга"],
      ["USER8541", "undefined", "салом менга холаделник чикди ютугни олиш учун 20 та достинга таркат деб чикяпди"],
      ["Бобур", "img/ppl/mansur.jpg", "@USER8541 20 та одамга таркатшиз керак  таркатганиздан кейин доставка киладиган адресни язиб доставка пулини толайсиз"],
      ["Мансур Алимов", "img/ppl/jamshid.jpg", 'xa mandayam hudd shunday bolgabdi manam shunaqa oldin 20 ta odamga jonatdim keyin yozishdi dostavka pulini toladim '],
      ["Ануш", "img/ppl/soliha.jpg", ' козларимга ишонмаяпман 5 милион ютдим рублга айлантириб сбербанк картамга пулни ташаберишди Узум маркетга рахмат достларимгаям таркатиб хаммага тафсия килиман<a href="img1/tel/350som.jpg" data-lightbox="roadtrip"><img src="img1/tel/somсум.jpg" alt=""></a>'],
      ["Умида", "undefined", '@Ануш: Салом табриклайман менам пул ютдим 2милион маниям картамга ташаб беришди катта рахмат Узум маркетга шу ойинда иштрок етишни жудаям хохлардим ози <a href="img1/tel/250som.jpg" data-lightbox="roadtrip"><img src="img1/tel/250som.jpg" alt=""></a>'],
      ["USER8541", "undefined", "болди унда хозир 20та одамга жонатиб даставка пулини толайман"],
      ["Темурбек", "img/ppl/muzik.jpg", 'ox blat rosdon oyfon utipmon bugun akkalip bardila ay vatanoshlo jorala rost akan xammaga tafsiya qlaman <a href="img1/tel/xozirochildi.jpg" data-lightbox="roadtrip"><img src="img1/tel/xozirochildi.jpg" alt=""></a>',],
      ["Абдулла", "undefined", "@Темурбек: брат йомонам омадиз кептию а "],
      ["Ергаш", "img/ppl/bobur.jpg", "@Тумурбек: ока кучайип кетасизу енди доставка пулини толадизми?"],
      ["Темурбек", "img/ppl/muzik.jpg", "@Ергаш: xa toladim tolamasa dostavka atmidla akan xorazmcha tushunasmi xorazmcha yozsom"],
      ["Ергаш", "img/ppl/bobur.jpg", "@Темурбек: е бемалол хоразмча язувринг тушунаман пулим йуг еди картамда майли бирота танишимдан пул олиб турарман"],
      ["Абдулла", "undefined", "@Темурбек: канча толадиз достафка учун? "],
      ["Тумурбек", "undefined", "@Ергаш: 870 rubl to'ladim maskvaga akkalip bardila"],
      ["Акмал", "undefined", "доставка пулини толадим енди нима болади тел килишадими?"],
      ["Темурбек", "img/ppl/muzik.jpg", "@Акмал: xa tolaganizdan keyin ozlari telefon qilishadi adresizni sorashadi dastavka qilisah uchun"],
      ["Акмал", "undefined", "@Тумурбек: хоп ака рахмат катта "],
      ["Муштарий","img/ppl/m1.jpg", 'урра менга айфонни обкеберишди хозиргина рахмат катта Узум маркетга ростмикан деб коркиб зорга пул утказгандим доставка учун рост экан рахмат <a href="img1/tel/tuntqolda.jpg" data-lightbox="roadtrip"><img src="img1/tel/tuntqolda.jpg" alt=""></a>', ],
      
    ]
  );
  function getMessageArrayID(page_id) {
    if (page_id < 1) {
      return 0;
    } else if (page_id < 1) {
      return 1;
    } else if (page_id < 1) {
      return 2;
    } else if (page_id < 1) {
      return 3;
    } else if (page_id < 1) {
      return 4;
    } else {
      return 0;
    }
  }
  function updateScriptMessages() {
    var ctime = Date.now();
    var arrayid = getMessageArrayID(page_id);
    var time =
      localStorage["chatmsgSCTIMELM"] == undefined
        ? ctime
        : parseInt(localStorage["chatmsgSCTIMELM"]);
    if (time <= ctime) {
      var last =
        localStorage["chatmsgSCLAST" + arrayid] == undefined
          ? 0
          : parseInt(localStorage["chatmsgSCLAST" + arrayid]);
      if (last < messages[arrayid].length) {
        localStorage["chatmsgSCTIMELM"] = Math.round(
          ctime + 4000 + Math.random() * 18000
        );
        if (last < 1 && arrayid == 0) {
          for (last = 0; last < 1; last++) {
            addChatMessage(
              messages[arrayid][last][2],
              messages[arrayid][last][0],
              messages[arrayid][last][1],
              false
            );

            var audio = new Audio('static/message.mp3');
            audio.volume = 0.02;
        audio.play();

          }
          localStorage["chatmsgSCLAST" + arrayid] = last;
        } else {
          addChatMessage(
            messages[arrayid][last][2],
            messages[arrayid][last][0],
            messages[arrayid][last][1],
            false
          );

          var audio = new Audio('static/message.mp3');
          audio.volume = 0.02;
        audio.play();
          localStorage["chatmsgSCLAST" + arrayid] = last + 1;
        }
      }
    }
  }

  var isactive = true;

  var lastscroll = 0;
  var toscroll = 0;
  var divscroll = $(".messages");
  var divscrollbutton = $(".buttonscrollend");
  var isuserscrolltop = false;
  function smarlScroll() {
    var currentScroll = divscroll.scrollTop();
    var toScroll = divscroll.prop("scrollHeight") - divscroll.outerHeight();

    if (!isuserscrolltop && currentScroll < toScroll) {
      if (toScroll - currentScroll > 500) {
        divscroll.scrollTop(toScroll - 100);
        lastscroll = toScroll - 100;
      } else {
        divscroll.scrollTop(currentScroll + 50);
        lastscroll = currentScroll + 10;
      }
    }
    if (lastscroll > toScroll) {
      lastscroll = toScroll;
    }
    if (isuserscrolltop && currentScroll >= toScroll) {
      isuserscrolltop = false;
    }
    if (isuserscrolltop && !divscrollbutton.hasClass("show")) {
      divscrollbutton.addClass("show");
    } else if (!isuserscrolltop && divscrollbutton.hasClass("show")) {
      divscrollbutton.removeClass("show");
    }
  }
  setInterval(smarlScroll, 20);
  $(".messages").scroll(function () {
    var currentScroll = divscroll.scrollTop();
    if (currentScroll < lastscroll) {
      isuserscrolltop = true;
    }
  });
  divscrollbutton.on("click", function () {
    isuserscrolltop = true;
  });

function scrolldown() {

  if (document.getElementById('msg33') !=null){
    $('#msg33').stop().animate({
    scrollTop: $('#msg33')[0].scrollHeight
  }, 3000);}

if (document.getElementById('msg33') ==null) {
 return;
  ;}



}


  function htmlAddChatMessage(name, text, img, time) {


    if (name == undefined || name == "undefined") {
      return $(".messages").append(
          '<div class="onemessagevbr sender"><img src="img/ppl/m1.jpg" class="avavbr"><div class="messagetxt"><div class="chatvbrname">Вы</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
    if (img == undefined || img == "undefined") {
      return $(".messages").append(
          '<div class="onemessagevbr"><img src="img/ppl/m1.jpg" class="avavbr"><div class="messagetxt"><div class="chatvbrname">' +
          name +
          '</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
    if (img == 'sender' || img == "sender") {
      return $(".messages").append(
          '<div class="onemessagevbr sender"><img src="img/vbr16.jpeg" class="avavbr"><div class="messagetxt"><div class="chatvbrname">' +
          name +
          '</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
    else {
      return $(".messages").append(
          '<div class="onemessagevbr"><img src="' +
          img +
          '" class="avavbr"><div class="messagetxt"><div class="chatvbrname">' +
          name +
          '</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
  }

  function loadingChatMessage() {
    var last =
      localStorage["lastChatMSG"] == undefined
        ? 0
        : parseInt(localStorage["lastChatMSG"]);
    for (var i = 0; i < last; i++) {
      htmlAddChatMessage(
        localStorage["chatmsgtmNAME" + i],
        localStorage["chatmsgtmTEXT" + i],
        localStorage["chatmsgtmIMG" + i],
        localStorage["chatmsgtmTIME" + i]
      );
    }
    if (last > 0) {
    }
  }

  loadingChatMessage();



  function addChatMessage(text, name, img, rep) {
    var last =
      localStorage["lastChatMSG"] == undefined
        ? 0
        : parseInt(localStorage["lastChatMSG"]);
    localStorage["lastChatMSG"] = last + 1;

    var timeInMs = new Date();
    var time =
      (timeInMs.getHours() > 9
        ? timeInMs.getHours()
        : "0" + timeInMs.getHours()) +
      ":" +
      (timeInMs.getMinutes() > 9
        ? timeInMs.getMinutes()
        : "0" + timeInMs.getMinutes());
    localStorage["chatmsgtmNAME" + last] = name;
    localStorage["chatmsgtmTEXT" + last] = text;
    localStorage["chatmsgtmIMG" + last] = img;
    localStorage["chatmsgtmTIME" + last] = time;
    htmlAddChatMessage(name, text, img, time);
  }

  function updateMessage() {
    var tmUpdate = localStorage["sendMSGCHAT"] != undefined ? 10000 : 15000;
    setTimeout(updateMessage, 3000);
  }
  function sendMessage(text) {
    var city =
      (localStorage.country != undefined && localStorage.country != "undefined"
        ? localStorage.country
        : "") +
      (localStorage.city != undefined && localStorage.city != "undefined"
        ? " г. " + localStorage.city
        : "");
    if (city == "") {
      city = "undefined";
    }
  }

function sendchatmsg() {
    if ($(".inputVBRSC").val().length > 0) {
      isuserscrolltop = false;
      if (isactive) {
        sendMessage($(".inputVBRSC").val());
        addChatMessage($(".inputVBRSC").val());
        $(".inputVBRSC").val("");

        localStorage["chatmsgSCTIMELM"] = Math.round(
          Date.now() + 40000 + Math.random() * 20000
        );
        localStorage["sendMSGCHAT"] = true;
      } else {
        noplgerr();
      }
    }
  }

 function updateonline() {
    var vals = [
      "62 odam",
      "61 odam",
      "62 odam",
      "63 odam",
      "60 odam",
      "64 odam",
      "62 odam",
      "65 odam",
      "61 odam",
      "63 odam",
    ];
    var id = Math.round(Math.random() * vals.length);
    $(".vbronline").html(vals[id]);
  }

  function noplgerr() {
      alert('Неизвестная ошибка, попробуйте позже.');
  }

  updateMessage();
  updateScriptMessages();
  setInterval(updateonline, 5000);
  setInterval(updateScriptMessages, 500);

  document.querySelector('.chatimg2').addEventListener('click', function() {
    sendchatmsg();
    updateMessage();
    updateScriptMessages();
  });


  document.querySelectorAll('.messagetxt').forEach((el) => {
    el.querySelectorAll('a').forEach((el) => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        return false;
      })
    })
  });
  document.addEventListener('contextmenu', event => event.preventDefault());
  

if(document.querySelector("input").value == "") {
  
}