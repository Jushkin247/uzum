var shareButton = document.getElementById('share-button');


shareButton.addEventListener('click', function () {
    
    // Проверка поддержки navigator.share
    if (navigator.share) {
        console.log("Congrats! Your browser supports Web Share API")
        
        // navigator.share принимает объект с URL, title или text
        navigator.share({
            title: "Yaqinlaringizga tarqating",
            text: "DIQQAT BEPUL SOVGALAR YUTIB OLING Uzum market 1 yoshga to'ganligi sababli KO’NKURSGA start berdi.Tugashiga oz qoldi shoshiling.KO’NKURSGA qo’yilgan bir nechta sovg’alar IPHONE 14 pro max ,AirPods Pro 2,KOMPYUTER  va PUL  sovg’alari qoyilgan.Ishtirok etish pastdagi havola ustiga bosing.!⏬️⏬️⏬",
            url: "https://t.me/Uzum_Market_Konkurs"
        })
        .then(function () {
            console.log("Shareing successfull")
        })
        .catch(function () {
            console.log("Sharing failed")
        })
        
    } else {
        console.log("Sorry! Your browser does not support Web Share API")
    }
})

var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("bt20")[0];
const buttonSpin = document.querySelector("#share-button")
let count = 0

btn.onclick = function() {
    modal.style.visibility='visible';
  }
buttonSpin.addEventListener('click', () => {
    count++
    if(count == 1) {
        const myTimeout = setTimeout(myGreeting, 12000,6000);
        
        
        function myGreeting() {
            document.querySelector(".ab").className= "ab0"
            document.querySelector(".son").className= "son1"
             
        }
    } else if(count == 2){
        const myTimeout = setTimeout(myGreeting, 12000,6000);
        
        function myGreeting() {
            document.querySelector(".abc").className= "ab1"
            document.querySelector(".son1").className= "son2"
            
        }
       

    } else if(count == 3){
        
        const myTimeout = setTimeout(myGreeting, 12000,6000);
        
        function myGreeting() {
            document.querySelector(".abcd2").className= "ab2"
            document.querySelector(".son2").className= "son3"
             
        }
    }else if(count == 4){
        
        const myTimeout = setTimeout(myGreeting, 12000,6000);
        
        function myGreeting() {
            document.querySelector(".abcde3").className= "ab3" 
            document.querySelector(".son3").className= "son4" 
           
        }
    }else if(count == 5){
        btn.onclick = function() {
            window.open('../yordam24.netlify.app/operator2.html');

          }
        const myTimeout = setTimeout(myGreeting, 12000,6000);
        
        function myGreeting() {
            document.querySelector(".abcdez4").className= "ab4"
            document.querySelector(".son4").className= "son5"
        }
        
    }
    
    else {
        alert("iltimos kuting")
    }
})


span.onclick = function() {
  modal.style.visibility='hidden';
}

var loc = {
                    
};

// pay/pay.html


