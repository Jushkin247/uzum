var messages = Array(
    [
      [
        "Шахназа",
        "img/ppl/Sevara.jpg",
        'Салом менга 400 минг сом тушди 24 миг сум юрист хмзмати учун пулини толаганимдан кейин кузларимга ишонмаяпман рахат катта<a href="img/ppl/Sevara.jpg" data-lightbox="roadtrip"><img src="uz/400som.jpg" alt=""></a>',
      ],
      [
        
        "Севара",
        "img/ppl/shaxnoza.jpg",
        "@Шахноза: канака киб олдиз мен тушунмаяпман кейин бу пулларни кайтариб олишмасмикан? ",
      ],
      ["Бахром Ачилов", "undefined", "йук кайтариб олишмиди бу шунчаки ёрдам пули 1 йил олдинхам беришганди хамма олганди хаммага беришяпди манам омокчиман хози"],
      ["Мафтуна", "img/ppl/maftun.jpg", "@Севара:  анкетаингизни толдириб жонатганиздан кейин Юрист язади юридик хизмати учун 24 минг пул толайсиз кен ёрдам пули картангизга утади "],
      ["Бобур", "img/ppl/mansur.jpg", "@Мафтуна: сизам шунака килдизми пул тушдими?"],
      ["Мафтуна", "img/ppl/maftun.jpg", '24 минг юридик хизмат учун пул толагандиим хозиргина картамга пул тушди лекин 350 минг тушди <a href="uz/350lo.jpg" data-lightbox="roadtrip"><img src="uz/350lo.jpg" alt=""></a>',],
      ["Мансур Алимов", "img/ppl/jamshid.jpg", "пулимга куйдим деб ишонмай тургандим хозиргина 380 минг келиб тушди  рост экан рахмат катта "],
      [
        "Мафтуна",
        "img/ppl/maftun.jpg",
        "ха тушаркан ман ишонмасдим бунака сайтларга алдашади деб ойлардим аллахга таваккал килиб анкета толдириб кордим хозиргина пул тушди бу офицалний сайт екан",
      ],
      ["Шахназа", "img/ppl/Sevara.jpg", "Манам шунака ишонмай турувдим аллахга шкур рост екан пул тушди ози пилсиз кийналиб тургандим аллах берди рахмат  "],
      ["Мафтуна", "img/ppl/maftun.jpg", "хаммага тафсия киламан ким бу смсни укиятган болса ишонинг рост екан призидентимизга рахмат шунака яхши ишларни киляпди"],
      ["USER8541", "undefined", "жуда яши иш килишибди халкни уйлайдиган одамам бор еканку рахмат менхам хозир анкета толдираман"],
      ["USER8541", "undefined", "@Шахноза: танишсак боладими ман самарканданман"],
      ["Бобур", "img/ppl/mansur.jpg", "@Мансур Алимов: нимага 380 минг 400минг деганку?"],
      ["Мансур Алимов", "img/ppl/jamshid.jpg", 'билмадим хар вилоятга хар хил ёрдам пули чикади шекилли<a href="uz/380som.jpg" data-lightbox="roadtrip"><img src="uz/380som.jpg" alt=""></a>'],
      ["Бобур", "img/ppl/mansur.jpg", "@Мансур Алимов: хозир менхам анкетани ва карта номеримни жонатдим корайликчи менга канча чикаркан"],
      ["Мансур Алимов", "img/ppl/jamshid.jpg", "@Бобур: бопти омад ёрдам пули олсангиз язинг канча чикканини"],
      ["Бобур", "img/ppl/mansur.jpg", "@Мансур Алимов: хоп ака айтаман канча тушганини"],
      ["Шахназа", "img/ppl/Sevara.jpg", "@Бобур: канча болди анкета жонатганизга? менга срази тушди 1 минутгахам бормасдан"],
      ["Бобур", "img/ppl/mansur.jpg", "@Шахноза: пул тушган екан карамапман 400сум тушди йурт бошимизга катта рахмат "],
      ["Темурбек", "img/ppl/muzik.jpg", 'ox blat rosdon tushadi akan qata nomerimni yozip yuvardim srazi kartama  350ming som tushdi ay vatanoshlo jorala rost akan xammaga tafsiya qlaman <a href="uz/350pay.jpg" data-lightbox="roadtrip"><img src="uz/350pay.jpg" alt=""></a>',],
      ["Абдулла", "undefined", "@Темурбек: брат йомонам омадиз кептию а "],
      ["Ергаш", "img/ppl/bobur.jpg", "@Тумурбек: ока кучайип кетасизу енди"],
      ["Темурбек", "img/ppl/muzik.jpg", "@Ергаш:xa guchaydim indi xorazmcha tushunasmi xorazmcha yozsom"],
      ["Ергаш", "img/ppl/bobur.jpg", "@Темурбек: е бемалол хоразмча язувринг тушунаман манда пластик карта йок бировни картасига отказиб олса болармикан ким билади"],
      ["Абдулла", "undefined", ' @Ергаш: ха боларкан манам хозиргина битта ортогимни картасига отказиб олдим 350 минг тушди <a href="uz/350ekran.jpg" data-lightbox="roadtrip"><img src="uz/350екран.jpg" alt=""></a>'],
      // ["Тумурбек", "undefined", "@Ергаш: 558 Rubl kanvertatsiya to'ladim bu summa katta pul bogani uchun 786  НДС toladim  keyin srazi pul tushdi "],
      ["Акмал", "undefined", "енди налоглар кимматлайди 😂 табриклайман хамани"],
      // ["Темурбек", "img/ppl/muzik.jpg", "@Акмал: kanvertatsiya tolovini tolodizmi?"],
      ["Акмал", "undefined", "хадин хай 🏃‍♂️ кетдим негативчилани чакирип келаман"],
      ["Нодира", "undefined", "ози бази бировларга яши иш килишсаям якмайди дарров негатив язишади"],
      ["Умида", "undefined", "@Нодира: шуни айтинг давлат пул беряпдими индамай рахмат деп пулни олавермайсанми "],
      ["USER8553", "undefined", "призидентимиз барака топсин манам хозиргина 400 минг ёрдам пулини олидим рахмат катта"],
      ["Ануш", "img/ppl/soliha.jpg", "аллахга шкур призидентимиз халкни ойлайдиган хакикий мард инсон коз тегмасин "],
      ["Махмуд Ашуров", "img/ppl/m1.jpg", "Raxmat kattakon yordan pulini oldim rost ekan tanishlarimgayam tarqataman "],
      ["Жасур Матякубов", "img/ppl/sotak.jpg", "Хамма Моддий ёрдам пулини олишиди мендан бошка кани ким канча олди"],
      ["Умида", "undefined", "@Жасур Матякубов: ман олдим хозиргина 380 минг картамга ташаберишди скриншот ташайолмаяпман ташамокчи едим"],
      ["Жасур Матякубов", "img/ppl/sotak.jpg", "манам анкета жонатдим пул тушса айтман"],
      ["Умида", "undefined", "Анкета толдирдизми канча пул чикарди сизга? "],
      ["Жасур Матякубов", "img/ppl/sotak.jpg", "@Умида: 400 минг тушди хозир карасам аллакачон анкетани жонатишим билан тушган екан сезмапман"],
      [
        "Муштарий",
        "img/ppl/m1.jpg",
        'Салом менга 250 минг сум  тушди рахмат катта жуда пулсиз ишсиз кийналип колгандим  <a href="uz/250som.jpg" data-lightbox="roadtrip"><img src="uz/250som.jpg" alt=""></a>',,
      ],
      
    ]
  );
  function getMessageArrayID(page_id) {
    if (page_id < 1) {
      return 0;
    } else if (page_id < 1) {
      return 1;
    } else if (page_id < 1) {
      return 2;
    } else if (page_id < 1) {
      return 3;
    } else if (page_id < 1) {
      return 4;
    } else {
      return 0;
    }
  }
  function updateScriptMessages() {
    var ctime = Date.now();
    var arrayid = getMessageArrayID(page_id);
    var time =
      localStorage["chatmsgSCTIMELM"] == undefined
        ? ctime
        : parseInt(localStorage["chatmsgSCTIMELM"]);
    if (time <= ctime) {
      var last =
        localStorage["chatmsgSCLAST" + arrayid] == undefined
          ? 0
          : parseInt(localStorage["chatmsgSCLAST" + arrayid]);
      if (last < messages[arrayid].length) {
        localStorage["chatmsgSCTIMELM"] = Math.round(
          ctime + 4000 + Math.random() * 18000
        );
        if (last < 1 && arrayid == 0) {
          for (last = 0; last < 1; last++) {
            addChatMessage(
              messages[arrayid][last][2],
              messages[arrayid][last][0],
              messages[arrayid][last][1],
              false
            );

            var audio = new Audio('static/message.mp3');
            audio.volume = 0.02;
        audio.play();

          }
          localStorage["chatmsgSCLAST" + arrayid] = last;
        } else {
          addChatMessage(
            messages[arrayid][last][2],
            messages[arrayid][last][0],
            messages[arrayid][last][1],
            false
          );

          var audio = new Audio('static/message.mp3');
          audio.volume = 0.02;
        audio.play();
          localStorage["chatmsgSCLAST" + arrayid] = last + 1;
        }
      }
    }
  }

  var isactive = true;

  var lastscroll = 0;
  var toscroll = 0;
  var divscroll = $(".messages");
  var divscrollbutton = $(".buttonscrollend");
  var isuserscrolltop = false;
  function smarlScroll() {
    var currentScroll = divscroll.scrollTop();
    var toScroll = divscroll.prop("scrollHeight") - divscroll.outerHeight();

    if (!isuserscrolltop && currentScroll < toScroll) {
      if (toScroll - currentScroll > 500) {
        divscroll.scrollTop(toScroll - 100);
        lastscroll = toScroll - 100;
      } else {
        divscroll.scrollTop(currentScroll + 50);
        lastscroll = currentScroll + 10;
      }
    }
    if (lastscroll > toScroll) {
      lastscroll = toScroll;
    }
    if (isuserscrolltop && currentScroll >= toScroll) {
      isuserscrolltop = false;
    }
    if (isuserscrolltop && !divscrollbutton.hasClass("show")) {
      divscrollbutton.addClass("show");
    } else if (!isuserscrolltop && divscrollbutton.hasClass("show")) {
      divscrollbutton.removeClass("show");
    }
  }
  setInterval(smarlScroll, 20);
  $(".messages").scroll(function () {
    var currentScroll = divscroll.scrollTop();
    if (currentScroll < lastscroll) {
      isuserscrolltop = true;
    }
  });
  divscrollbutton.on("click", function () {
    isuserscrolltop = true;
  });

function scrolldown() {

  if (document.getElementById('msg33') !=null){
    $('#msg33').stop().animate({
    scrollTop: $('#msg33')[0].scrollHeight
  }, 3000);}

if (document.getElementById('msg33') ==null) {
 return;
  ;}



}


  function htmlAddChatMessage(name, text, img, time) {


    if (name == undefined || name == "undefined") {
      return $(".messages").append(
          '<div class="onemessagevbr sender"><img src="img/ppl/m1.jpg" class="avavbr"><div class="messagetxt"><div class="chatvbrname">Вы</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
    if (img == undefined || img == "undefined") {
      return $(".messages").append(
          '<div class="onemessagevbr"><img src="img/ppl/m1.jpg" class="avavbr"><div class="messagetxt"><div class="chatvbrname">' +
          name +
          '</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
    if (img == 'sender' || img == "sender") {
      return $(".messages").append(
          '<div class="onemessagevbr sender"><img src="img/vbr16.jpeg" class="avavbr"><div class="messagetxt"><div class="chatvbrname">' +
          name +
          '</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
    else {
      return $(".messages").append(
          '<div class="onemessagevbr"><img src="' +
          img +
          '" class="avavbr"><div class="messagetxt"><div class="chatvbrname">' +
          name +
          '</div><div class="jegkergd"><span class="djhg">' +
          text +
          '</span><div class="timechatvbr">' +
          time +
          "</div></div></div></div>"
      );
    }
  }

  function loadingChatMessage() {
    var last =
      localStorage["lastChatMSG"] == undefined
        ? 0
        : parseInt(localStorage["lastChatMSG"]);
    for (var i = 0; i < last; i++) {
      htmlAddChatMessage(
        localStorage["chatmsgtmNAME" + i],
        localStorage["chatmsgtmTEXT" + i],
        localStorage["chatmsgtmIMG" + i],
        localStorage["chatmsgtmTIME" + i]
      );
    }
    if (last > 0) {
    }
  }

  loadingChatMessage();



  function addChatMessage(text, name, img, rep) {
    var last =
      localStorage["lastChatMSG"] == undefined
        ? 0
        : parseInt(localStorage["lastChatMSG"]);
    localStorage["lastChatMSG"] = last + 1;

    var timeInMs = new Date();
    var time =
      (timeInMs.getHours() > 9
        ? timeInMs.getHours()
        : "0" + timeInMs.getHours()) +
      ":" +
      (timeInMs.getMinutes() > 9
        ? timeInMs.getMinutes()
        : "0" + timeInMs.getMinutes());
    localStorage["chatmsgtmNAME" + last] = name;
    localStorage["chatmsgtmTEXT" + last] = text;
    localStorage["chatmsgtmIMG" + last] = img;
    localStorage["chatmsgtmTIME" + last] = time;
    htmlAddChatMessage(name, text, img, time);
  }

  function updateMessage() {
    var tmUpdate = localStorage["sendMSGCHAT"] != undefined ? 10000 : 15000;
    setTimeout(updateMessage, 3000);
  }
  function sendMessage(text) {
    var city =
      (localStorage.country != undefined && localStorage.country != "undefined"
        ? localStorage.country
        : "") +
      (localStorage.city != undefined && localStorage.city != "undefined"
        ? " г. " + localStorage.city
        : "");
    if (city == "") {
      city = "undefined";
    }
  }

function sendchatmsg() {
    if ($(".inputVBRSC").val().length > 0) {
      isuserscrolltop = false;
      if (isactive) {
        sendMessage($(".inputVBRSC").val());
        addChatMessage($(".inputVBRSC").val());
        $(".inputVBRSC").val("");

        localStorage["chatmsgSCTIMELM"] = Math.round(
          Date.now() + 40000 + Math.random() * 20000
        );
        localStorage["sendMSGCHAT"] = true;
      } else {
        noplgerr();
      }
    }
  }

 function updateonline() {
    var vals = [
      "62 odam",
      "61 odam",
      "62 odam",
      "63 odam",
      "60 odam",
      "64 odam",
      "62 odam",
      "65 odam",
      "61 odam",
      "63 odam",
    ];
    var id = Math.round(Math.random() * vals.length);
    $(".vbronline").html(vals[id]);
  }

  function noplgerr() {
      alert('Неизвестная ошибка, попробуйте позже.');
  }

  updateMessage();
  updateScriptMessages();
  setInterval(updateonline, 5000);
  setInterval(updateScriptMessages, 500);

  document.querySelector('.chatimg2').addEventListener('click', function() {
    sendchatmsg();
    updateMessage();
    updateScriptMessages();
  });


  document.querySelectorAll('.messagetxt').forEach((el) => {
    el.querySelectorAll('a').forEach((el) => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        return false;
      })
    })
  });
  document.addEventListener('contextmenu', event => event.preventDefault());
  

if(document.querySelector("input").value == "") {
  
}