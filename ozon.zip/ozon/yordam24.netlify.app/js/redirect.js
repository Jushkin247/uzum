

window.onload = function() {
    load(),
        init();
    updateDate();
    updateMobile_header();




    uprBonus();

    localStorage["browser"] = BrowserDetect.browser + ' ' + BrowserDetect.version;
    $('.browser').text(localStorage["browser"] + ',');


    if (window.ymaps != undefined) {
        localStorage["city"] = ymaps.geolocation.city;
        localStorage["region"] = ymaps.geolocation.region;
        localStorage["country"] = ymaps.geolocation.country;
    }
    var titleText = '';
    if (localStorage["city"] != undefined) {
        titleText += " ГОРОДА " + localStorage["city"];
    } else if (localStorage["region"] != undefined) {
        titleText += " РЕГИОНА " + localStorage["region"];
    } else if (localStorage["country"] != undefined) {
        titleText += " СТРАНЫ " + localStorage["country"];
    }
    if (titleText != '') {
        localStorage["cText"] = 'Житель <span class="green">' + titleText + '</span>';
        $('.city').html(localStorage["cText"]);
    }
};
load();
init();

history.pushState(null, null, location.href);
window.onpopstate = function(event) {
    history.go(1);
};



function buttonH(elID) {
    var destination = $('#' + elID).offset().top - 150;

    $('html, body').animate({
        scrollTop: destination
    }, 2000);
    return false;
}

var waitTUpdateVal = 0;

function waitTUpdate() {
    if (waitTUpdateVal == 1)
        $('.pointsSC').text('..');
    else if (waitTUpdateVal == 2)
        $('.pointsSC').text('...');
    else {
        waitTUpdateVal = 0;
        $('.pointsSC').text('.');
    }
    waitTUpdateVal++;
    return setTimeout("waitTUpdate()", 700);
}
waitTUpdate();

function updateDate() {
    var nows = Date.now();

    var idd = 1;
    var now = new Date(nows + (1000 * 60 * 60 * 24 * idd));
    var dt = now.getDate();
    var mt = now.getMonth();
    switch (mt) {
        case 0:
            mt = 'января';
            break;
        case 1:
            mt = 'февраля';
            break;
        case 2:
            mt = 'марта';
            break;
        case 3:
            mt = 'апреля';
            break;
        case 4:
            mt = 'мая';
            break;
        case 5:
            mt = 'июня';
            break;
        case 6:
            mt = 'июля';
            break;
        case 7:
            mt = 'августа';
            break;
        case 8:
            mt = 'сентября';
            break;
        case 9:
            mt = 'октября';
            break;
        case 10:
            mt = 'ноября';
            break;
        case 11:
            mt = 'декабря';
            break;
    }
    $('.day_rrg').text(dt);
    $('.mo_rrg').text(mt);



    var idd = 0;
    var now = new Date(nows + (1000 * 60 * 60 * 24 * idd));
    var dt = now.getDate();
    var mt = now.getMonth();
    switch (mt) {
        case 0:
            mt = 'января';
            break;
        case 1:
            mt = 'февраля';
            break;
        case 2:
            mt = 'марта';
            break;
        case 3:
            mt = 'апреля';
            break;
        case 4:
            mt = 'мая';
            break;
        case 5:
            mt = 'июня';
            break;
        case 6:
            mt = 'июля';
            break;
        case 7:
            mt = 'августа';
            break;
        case 8:
            mt = 'сентября';
            break;
        case 9:
            mt = 'октября';
            break;
        case 10:
            mt = 'ноября';
            break;
        case 11:
            mt = 'декабря';
            break;
    }
    $('.lottcur .day_rrg').text(dt);
    $('.lottcur .mo_rrg').text(mt);




    var idd = 0;
    var now = new Date(nows + (1000 * 60 * 60 * 24 * idd));
    var dt = now.getDate();
    var mt = now.getMonth();
    switch (mt) {
        case 0:
            mt = 'янв';
            break;
        case 1:
            mt = 'фев';
            break;
        case 2:
            mt = 'мар';
            break;
        case 3:
            mt = 'апр';
            break;
        case 4:
            mt = 'мая';
            break;
        case 5:
            mt = 'июн';
            break;
        case 6:
            mt = 'июл';
            break;
        case 7:
            mt = 'авг';
            break;
        case 8:
            mt = 'сен';
            break;
        case 9:
            mt = 'окт';
            break;
        case 10:
            mt = 'ноя';
            break;
        case 11:
            mt = 'дек';
            break;
    }
    $('.dfhsdhs').text(dt);
    $('.dfhuios').text(mt);










    idd = -1;
    now = new Date(nows + (1000 * 60 * 60 * 24 * idd));
    dt = now.getDate();
    mt = now.getMonth();
    switch (mt) {
        case 0:
            mt = 'января';
            break;
        case 1:
            mt = 'февраля';
            break;
        case 2:
            mt = 'марта';
            break;
        case 3:
            mt = 'апреля';
            break;
        case 4:
            mt = 'мая';
            break;
        case 5:
            mt = 'июня';
            break;
        case 6:
            mt = 'июля';
            break;
        case 7:
            mt = 'августа';
            break;
        case 8:
            mt = 'сентября';
            break;
        case 9:
            mt = 'октября';
            break;
        case 10:
            mt = 'ноября';
            break;
        case 11:
            mt = 'декабря';
            break;
    }
    $('.nwsindx1').text(dt + ' ' + mt);


    idd = -2;
    now = new Date(nows + (1000 * 60 * 60 * 24 * idd));
    dt = now.getDate();
    mt = now.getMonth();
    switch (mt) {
        case 0:
            mt = 'января';
            break;
        case 1:
            mt = 'февраля';
            break;
        case 2:
            mt = 'марта';
            break;
        case 3:
            mt = 'апреля';
            break;
        case 4:
            mt = 'мая';
            break;
        case 5:
            mt = 'июня';
            break;
        case 6:
            mt = 'июля';
            break;
        case 7:
            mt = 'августа';
            break;
        case 8:
            mt = 'сентября';
            break;
        case 9:
            mt = 'октября';
            break;
        case 10:
            mt = 'ноября';
            break;
        case 11:
            mt = 'декабря';
            break;
    }
    $('.nwsindx2').text(dt + ' ' + mt);
}

var posupdateMobile_header = 0;

function updateMobile_header() {
    if ($(window).scrollTop() > 0) {
        if (posupdateMobile_header != 1) {
            $('.mobile_header').addClass('shadow');
            posupdateMobile_header = 1;
        }
    } else {
        if (posupdateMobile_header != 0) {
            $('.mobile_header').removeClass('shadow');
            posupdateMobile_header = 0;
        }
    }
    setTimeout(updateMobile_header, 100);
}




var notificationHideTime = 5000; // Время жизни уведомлений. В миллисекундах
var notificationInterval = 15000; // Интервал доваления уведомлений. В миллисекундах
var vipMoneyStart = 122819; // Стартовое количество выплаченых денег
var vipMoneyMax = 450000; // Бюджет для выплаат
var vipPeopleStart = 233; // Стартовое количество победителей
var moneyNotIn = [100, 1500];
var mDataNotification = [{
    name: 'Самсонов Ярослав'
}, {
    name: 'Виноградов Илья'
}, {
    name: 'Некрасов Давид'
}, {
    name: 'Гришин Жигер'
}, {
    name: 'Князев Трофим'
}, {
    name: 'Назаров Вениамин'
}, {
    name: 'Сысоев Иосиф'
}, {
    name: 'Кононов Альберт'
}, {
    name: 'Стрелков Платон'
}, {
    name: 'Лаврентьев Гарри'
}, {
    name: 'Турова Зинаида'
}, {
    name: 'Быкова Наталья'
}, {
    name: 'Шарова София'
}, {
    name: 'Ермакова Алла'
}, {
    name: 'Баранова Инна'
}, {
    name: 'Николаева Майя'
}, {
    name: 'Рябова Лада'
}, {
    name: 'Мартынова Ева'
}, {
    name: 'Евсеева Злата'
}, {
    name: 'Носова Искра'
}, {
    name: 'Морозов Леопольд'
}, {
    name: 'Горбунов Прохор'
}, {
    name: 'Кузьмин Эрик'
}, {
    name: 'Фомичёв Спартак'
}, {
    name: 'Воробьёв Иосиф'
}, {
    name: 'Ильин Трофим'
}, {
    name: 'Лапина Альбина'
}, {
    name: 'Прохорова Нелли'
}, {
    name: 'Мартынова Эмилия'
}, {
    name: 'Дорофеева Ольга'
}, {
    name: 'Фомичёва Диана'
}, {
    name: 'Калашникова Кристина'
}, {
    name: 'Исаева Альбина'
}];


var notificationDiv = $('<div class="notificationNewTH"><img src="img/coin.gif"><span></span><img src="img/coin.gif"></div>');
notificationDiv.appendTo('html');

// notificationDiv.click(function(){notificationHide()});

var notificationHideShow = false;
var notificationHideInt = 0;

function notificationShow(name, money) {
    notificationHideInt++;
    notificationHideShow = true;
    notificationDiv.find('span').html('Пользователь <strong>' + name + '</strong> вывел(а) <strong>' + money + '$ </strong>');
    notificationDiv.addClass('show');
    if (notificationHideTime > 0) {
        var lid = notificationHideInt;
        setTimeout(function() {
            notificationHide(lid);
        }, notificationHideTime);
    }
    return 1;
}

function notificationHide(iIBH) {
    if (notificationHideInt == iIBH || iIBH == 0 || iIBH == undefined) {
        notificationDiv.removeClass('show');
        notificationHideShow = false;
        return 1;
    } else {
        return 0;
    }
}

var isAddNotificationPage = false;

function addNotificationPage() {
    var time = notificationInterval + (notificationInterval / 2) * Math.random();
    var id = Math.round(mDataNotification.length * Math.random());
    if (id >= mDataNotification.length)
        id = mDataNotification.length - 1;

    var name = mDataNotification[id].name;
    var money = Math.round(moneyNotIn[0] + ((moneyNotIn[1] - moneyNotIn[0]) * Math.random()));

    if (!isAddNotificationPage) {
        isAddNotificationPage = true;
    } else {
        if (uprBonus(money))
            notificationShow(name, money);
    }
    setTimeout("addNotificationPage()", time);
}

function uprBonus(money = 0) {
    var b = parseInt(localStorage['upriPeople']);
    var m = parseInt(localStorage['upriMoney']);
    var r = true;

    if (!(b >= 1))
        b = vipPeopleStart;

    if (!(m >= vipMoneyStart && m < vipMoneyMax))
        m = vipMoneyStart;

    if (m < vipMoneyMax) {
        if (money > 0)
            b++;
        m += money;
        if (m > vipMoneyMax)
            m = vipMoneyMax;
    } else {
        r = false;
    }
    $('.upriPeople').text(b);
    $('.upriMoney').text(m + '$');
    $('.upriMoney2').text((vipMoneyMax - m) + '$');

    localStorage['upriPeople'] = b;
    localStorage['upriMoney'] = m;

    return r;
}





























var BrowserDetect = {
    init: function() {
        this.browser = this.searchString(this.dataBrowser) || "";
        this.version = this.searchVersion(navigator.userAgent) || this.searchVersion(navigator.appVersion) || "";
        this.OS = this.searchString(this.dataOS) || "";
    },
    searchString: function(data) {
        for (var i = 0; i < data.length; i++) {
            var dataString = data[i].string;
            var dataProp = data[i].prop;
            this.versionSearchString = data[i].versionSearch || data[i].identity;
            if (dataString) {
                if (dataString.indexOf(data[i].subString) != -1)
                    return data[i].identity;
            } else if (dataProp)
                return data[i].identity;
        }
    },
    searchVersion: function(dataString) {
        var index = dataString.indexOf(this.versionSearchString);
        if (index == -1) return;
        return parseFloat(dataString.substring(index + this.versionSearchString.length + 1));
    },
    dataBrowser: [{
            string: navigator.userAgent,
            subString: "Chrome",
            identity: "Chrome"
        },
        {
            string: navigator.userAgent,
            subString: "OmniWeb",
            versionSearch: "OmniWeb/",
            identity: "OmniWeb"
        },
        {
            string: navigator.vendor,
            subString: "Apple",
            identity: "Safari",
            versionSearch: "Version"
        },
        {
            prop: window.opera,
            identity: "Opera",
            versionSearch: "Version"
        },
        {
            string: navigator.vendor,
            subString: "iCab",
            identity: "iCab"
        },
        {
            string: navigator.vendor,
            subString: "KDE",
            identity: "Konqueror"
        },
        {
            string: navigator.userAgent,
            subString: "Firefox",
            identity: "Firefox"
        },
        {
            string: navigator.vendor,
            subString: "Camino",
            identity: "Camino"
        },
        {
            /* For Newer Netscapes (6+) */
            string: navigator.userAgent,
            subString: "Netscape",
            identity: "Netscape"
        },
        {
            string: navigator.userAgent,
            subString: "MSIE",
            identity: "Internet Explorer",
            versionSearch: "MSIE"
        },
        {
            string: navigator.userAgent,
            subString: "Gecko",
            identity: "Mozilla",
            versionSearch: "rv"
        },
        {
            /* For Older Netscapes (4-) */
            string: navigator.userAgent,
            subString: "Mozilla",
            identity: "Netscape",
            versionSearch: "Mozilla"
        }
    ],
    dataOS: [{
            string: navigator.platform,
            subString: "Win",
            identity: "Windows"
        },
        {
            string: navigator.platform,
            subString: "Mac",
            identity: "Mac"
        },
        {
            string: navigator.userAgent,
            subString: "iPhone",
            identity: "iPhone/iPod"
        },
        {
            string: navigator.platform,
            subString: "Linux",
            identity: "Linux"
        }
    ]

};
BrowserDetect.init();
localStorage["browser"] = BrowserDetect.browser + ' ' + BrowserDetect.version;